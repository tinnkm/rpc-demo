package com.tinnkm.rpc.simple.demo.service;

/**
 * Created by tinnkm on 2017/11/14.
 */
public interface IHelloService {
    String sayHello(String name);
}
